#! /bin/bash

lipo -create $@ -output liboutput.a