#include "Core.h"
#include "DiscordRpc.h"