#ifndef __STDBOOL_H
#define __STDBOOL_H

#ifdef __cplusplus

#define __bool_true_false_are_defined 1
#else

#define bool _Bool
#define true 1
#define false 0

#define __bool_true_false_are_defined 1
#endif

#endif /* __STDBOOL_H */