print("------------------ LuaFileSytem -------------------")

-- make sure the lfs.dll can be found
package.cpath = package.cpath .. ";C:\\tmp\\lualibs_windows\\luafilesystem\\?.dll"

require("lfs")
print(lfs._VERSION)
-- execute some code from the LuaFileSystemLib
print(lfs.currentdir())
for it,obj in lfs.dir(lfs.currentdir()) do
    print(it)
end

print("------------------ LuaSocket -------------------")

-- LuaSocket is distributed as a dll (core.dll) and a set of wrapper lua scripts, we need to make sure that all these
-- can somehow be found by lua by fudging package.cpath and package.path
package.cpath = package.cpath .. ";C:\\tmp\\lualibs_windows\\luasocket\\mime\\?.dll"
package.cpath = package.cpath .. ";C:\\tmp\\lualibs_windows\\luasocket\\?.dll"
package.path  = package.path .. ";C:\\tmp\\lualibs_windows\\luasocket\\?.lua"

require("socket")
print(socket._VERSION)
http = require("socket.http")

-- request our home page via the socket library
local ourHome = http.request("http://render.otoy.com")
print(ourHome)