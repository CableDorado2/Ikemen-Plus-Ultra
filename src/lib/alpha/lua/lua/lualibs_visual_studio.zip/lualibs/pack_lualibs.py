# packs the lua libraries in a zip file

import os
import os.path
import zipfile

# directory with the dlls
dll_dir = os.path.join(os.curdir, "bin/windows/release_64")

with zipfile.ZipFile('lualibs_windows.zip', 'w') as zf:
    # LuaFileSystem
    zf.write(os.path.join(dll_dir, "lfs.dll"), "luafilesystem/lfs.dll")

    # LuaSocket
    luasocket_src_dir = os.path.join(os.curdir, "src/luasocket-3.0-rc1/src")
    zf.write(os.path.join(dll_dir, "luasocket.dll"), "luasocket/socket/core.dll")
    zf.write(os.path.join(luasocket_src_dir, "socket.lua"), "luasocket/socket.lua")
    zf.write(os.path.join(luasocket_src_dir, "ltn12.lua"), "luasocket/ltn12.lua")
    zf.write(os.path.join(luasocket_src_dir, "http.lua"), "luasocket/socket/http.lua")
    zf.write(os.path.join(luasocket_src_dir, "tp.lua"), "luasocket/socket/tp.lua")
    zf.write(os.path.join(luasocket_src_dir, "ftp.lua"), "luasocket/socket/ftp.lua")
    zf.write(os.path.join(luasocket_src_dir, "smtp.lua"), "luasocket/socket/smtp.lua")
    zf.write(os.path.join(luasocket_src_dir, "url.lua"), "luasocket/socket/url.lua")
    zf.write(os.path.join(luasocket_src_dir, "headers.lua"), "luasocket/socket/headers.lua")
    zf.write(os.path.join(luasocket_src_dir, "mime.lua"), "luasocket/mime.lua")
    zf.write(os.path.join(dll_dir, "luamime.dll"), "luasocket/mime/core.dll")
