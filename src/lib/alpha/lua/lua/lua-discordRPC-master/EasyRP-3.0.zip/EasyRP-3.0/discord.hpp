void updatePresence(config_t *c);

void initDiscord(std::string client_id);

void refreshDiscord();

void Shutdown(int sig);
